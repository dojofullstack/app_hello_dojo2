package com.example.app_hello_dojo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
